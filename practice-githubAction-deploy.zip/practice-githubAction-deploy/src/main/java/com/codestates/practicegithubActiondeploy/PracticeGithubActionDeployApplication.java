package com.codestates.practicegithubActiondeploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeGithubActionDeployApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeGithubActionDeployApplication.class, args);
	}

}
